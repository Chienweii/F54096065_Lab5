import pygame
import os

# put images in 順便調大小
upgrade = pygame.transform.scale(pygame.image.load(os.path.join("images", "upgrade.png")), (70, 40))
sell = pygame.transform.scale(pygame.image.load(os.path.join("images", "sell.png")), (40, 40))

upgrade_menu = pygame.image.load(os.path.join("images", "upgrade_menu.png"))
class UpgradeMenu:
    def __init__(self, x, y):
        #調整按鈕位置
        self.__buttons = [Button(upgrade, "upgrade",x,y - 75), Button(sell,"sell", x, y + 70)]  # (Q2) Add buttons here
        #設置menu
        self.image = pygame.transform.scale(upgrade_menu, (200, 200))
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

        # 設置按紐
        self.upgrade_rect = upgrade.get_rect()
        self.upgrade_rect.center = (x, y)
        self.sell_rect = sell.get_rect()
        self.sell_rect.center = (x, y)

    def draw(self, win):
        """
        (Q1) draw menu itself and the buttons
        (This method is call in draw() method in class TowerGroup)
        :return: None
        """
        win.blit(self.image, self.rect)#擺放菜單位置
        # draw menu
        #綠色為錯誤嘗試～～
        """for mn in self.__menu:
            win.blit(mn.image, mn.rect)
        # draw tower range
        if self.selected_tower is not None:
            self.selected_tower.draw_effect_range(win)
            self.upgrade_menu.draw(win)
            """
        #擺放按鈕位置
        for button in self.__buttons:
            win.blit(button.image, button.rect)
        # draw button
        # (Q2) Draw buttons here
        """self.rect=image.get.rect
        pass"""

    def get_buttons(self):
        """
        (Q1) Return the button list.
        (This method is call in get_click() method in class TowerGroup)
        :return: list
        """
        pass


class Button:
    def __init__(self, image, name, x, y):
        self.name = name
        self.image = image
        self.rect = image.get_rect()
        self.rect.center = (x, y)


    def clicked(self, x, y):
        """
        (Q2) Return Whether the button is clicked
        (This method is call in get_click() method in class TowerGroup)
        :param x: mouse x
        :param y: mouse y
        :return: bool
        """

        for bt in self.__botton:
            if bt.clicked(x, y):
                self.selected_botton = bt
                return
            # if the button is clicked, get the button response.
            # and keep selecting the tower.
        if self.upgrade is not None:
            for btn in self.upgrade.get_buttons():
                if btn.clicked(x, y):
                    self.button_response = btn.response()
            if self.button_response is None:
                self.selected_botton = None


    def response(self):
        """
        (Q2) Return the button name.
        (This method is call in get_click() method in class TowerGroup)
        :return: str
        """
        pass






