"""for mn in self.__menu:
            win.blit(mn.image, mn.rect)
        # draw tower range
        if self.selected_tower is not None:
            self.selected_tower.draw_effect_range(win)
            self.upgrade_menu.draw(win)"""
"""self.rect=image.get.rect
        pass"""